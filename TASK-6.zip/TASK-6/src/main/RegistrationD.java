package main;

public interface RegistrationD {

    public int insertData(Registration R);
}
