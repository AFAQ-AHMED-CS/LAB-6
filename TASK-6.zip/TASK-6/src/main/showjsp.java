package main;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/showjsp")
public class showjsp extends HttpServlet {
    protected void doPost( HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        RegistrationD RD=new RegistrationDI();
        String FName=request.getParameter("Fname");
        String LName=request.getParameter("Lname");
        String Gender=request.getParameter("gender");
        String city=request.getParameter("city");
        String country=request.getParameter("country");
        String Check=request.getParameter("check");

        String submit=request.getParameter("submit");

        Registration R=new Registration();
        if(submit.equals("Sub") && Check !=null ){
            R.setFname(FName);
            R.setLname(LName);
            R.setGender(Gender);
            R.setCity(city);
            R.setCountry(country);
            RD.insertData(R);
            request.getRequestDispatcher("welcome.jsp").forward(request,response);
        }else{
            request.getRequestDispatcher("index.jsp").forward(request,response);
        }
    }
}
