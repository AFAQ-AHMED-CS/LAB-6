package main;

import java.sql.Connection;
import java.sql.DriverManager;

public class MyConnectionrovider implements MyProvider{
    static Connection con=null;

    public static  Connection  getCon(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con= DriverManager.getConnection(connurl,username,password);
        }catch (Exception E){
            System.out.println(E);
        }
        return con;
    }
}
