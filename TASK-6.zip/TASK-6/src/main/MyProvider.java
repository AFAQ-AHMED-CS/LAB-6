package main;

public interface MyProvider {

    String username = "root";
    String password = "";
    String connurl = "jdbc:mysql://localhost:3306/project";
}
