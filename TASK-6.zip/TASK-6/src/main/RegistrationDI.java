package main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RegistrationDI implements RegistrationD{
    static Connection con;
    static PreparedStatement ps;

    @Override
    public int insertData(Registration R) {
        int status =0;
        try {
            con=MyConnectionrovider.getCon();
            ps=con.prepareStatement("insert into data values (?,?,?,?,?)");
            ps.setString(1,R.getFname());
            ps.setString(2,R.getLname());
            ps.setString(3,R.getGender());
            ps.setString(4,R.getCity());
            ps.setString(5,R.getCountry());
            status=ps.executeUpdate();
            con.close();;

        }catch (Exception E){
            System.out.println(E);
        }
        return status;
    }
}
